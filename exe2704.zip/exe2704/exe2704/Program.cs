﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exe2704
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;
            double v4;
            double media;

            Console.WriteLine("Digite o 1° valor: ");
            v1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2° valor: ");
            v2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 3° valor: ");
            v3 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 4° valor: ");
            v4 = double.Parse(Console.ReadLine());

            media = (v1 + v2 + v3 + v4) / 4;

            if (media >=6)
            {
                Console.WriteLine("Aprovado");
            }

            else
            {
                if (media>= 4)
                    {
                    Console.WriteLine("IFA");
                    }
                else
                {
                    Console.WriteLine("Reprovado");
                }
            }

        }
    }
}
