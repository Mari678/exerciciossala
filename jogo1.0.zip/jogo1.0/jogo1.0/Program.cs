﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jogo1._0
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int oc;
            int li = 1;
            int ls = 100;
            int palpite;
            int vez = 1;

            Console.WriteLine("Jogador oculto, digite um valor no intervalo de 1 a 100: ");
            oc = int.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Digite um valor no intervalo de 1 a 100: ");
                oc = int.Parse(Console.ReadLine());
            } while (oc >= 100 || oc <= 1);

            Console.Clear();

            do
            {
                do
                {
                    Console.WriteLine("Jogador {0}, digite um valor entre {1} e {2}: ", vez, li, ls);
                    palpite = int.Parse(Console.ReadLine());
                } while (palpite <= li || palpite >= ls);

                if (palpite == oc)
                {
                    Console.WriteLine("Parabéns jogador {0}, você perdeu!", vez);
                }

                else
                {
                    if (palpite < oc)
                    {
                        li = palpite;
                    }

                    else
                    {
                        ls = palpite;
                    }
                }

                vez = vez + 1;

                if (vez > 2)
                {
                    vez = 1;
                }
            } while (palpite != oc);


        }
    }
}
